@echo off 
echo Uninstalling AVAA Antivirus... 
echo Stopping service... 
sc stop AVAA_Service 
echo Deleting service... 
sc delete AVAA_Service 
echo Removing files... 
del /q "C:\Program Files\AVAA\AVAA.exe" 2>nul 
del /q "C:\Program Files\AVAA\AVAAService.exe" 2>nul 
del /q "C:\Program Files\AVAA\AVAAMockLicenseServer.exe" 2>nul 
rmdir "C:\Program Files\AVAA\" 2>nul 
echo. 
echo Uninstall complete! 
pause 
