AVAA Antivirus Installer 
 
======================================== 
AVAA Antivirus Installation Guide 
======================================== 
 
INSTALLATION: 
1. Right-click on install.bat and select "Run as Administrator" 
2. Follow the on-screen instructions 
3. After installation, launch AVAA.exe from Start Menu or Program Files 
 
UNINSTALLATION: 
1. Right-click on uninstall.bat and select "Run as Administrator" 
2. Follow the on-screen instructions 
 
Test credentials: 
Login: test 
Password: test 
Activation code: DEMO-KEY 
