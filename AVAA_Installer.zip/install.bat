@echo off 
echo Installing AVAA Antivirus... 
echo. 
echo Creating Program Files folder... 
mkdir "C:\Program Files\AVAA" 2>nul 
echo Copying files... 
copy /y AVAA.exe "C:\Program Files\AVAA\" 
copy /y AVAAService.exe "C:\Program Files\AVAA\" 
copy /y AVAAMockLicenseServer.exe "C:\Program Files\AVAA\" 
echo Installing service... 
sc create AVAA_Service binPath= "\"C:\Program Files\AVAA\AVAAService.exe\"" start= auto 
echo Starting service... 
sc start AVAA_Service 
echo. 
echo Installation complete! 
echo You can now run AVAA.exe from Start Menu or Program Files 
pause 
